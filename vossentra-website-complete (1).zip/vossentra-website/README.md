# Vossentra website

This is a complete static multi-page website for Vossentra.

## Files
- `index.html` — homepage
- `about.html` — about page
- `services.html` — services
- `solutions.html` — market solutions
- `contact.html` — contact form
- `thank-you.html` — form confirmation page
- `404.html` — not-found page
- `styles.css` and `script.js` — styling and mobile navigation
- `assets/img/` — logo files

## Publish
Upload the contents of this folder to a GitHub repository, keeping `index.html` in the repository root. You can deploy it with Netlify by importing the GitHub repository.

The contact form is configured for Netlify Forms. It will collect submissions after the site is deployed through Netlify. The contact email currently shown is `ezejah.growth@gmail.com`; change it in the HTML files if you want a different address.

The site uses a remote Google Fonts stylesheet; if unavailable, it falls back to system fonts.
